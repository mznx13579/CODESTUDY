package com.ssafy.happyhouse.repo;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.ssafy.happyhouse.dto.QnADTO;

@Mapper
public interface QnARepo {
	public List<QnADTO> selectQnAList();
	public QnADTO selectQnAOne(int no);
	public int insert(QnADTO dto);
	public int update(QnADTO dto);
	public int updateHit(int no);
	public int delete(int no);
}
