package com.ssafy.happyhouse.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.tomcat.util.net.openssl.ciphers.Authentication;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.happyhouse.dto.UserDTO;
import com.ssafy.happyhouse.service.EncryptHelper;
import com.ssafy.happyhouse.service.UserService;

import io.swagger.annotations.ApiOperation;

//http://localhost:9999/ssafyfinal/swagger-ui.html
@CrossOrigin(origins = { "*" }, maxAge = 6000)
@RestController
@RequestMapping("/api/user")
public class UserController {
	private static final Logger logger = LoggerFactory.getLogger(UserController.class);
	private static final String SUCCESS = "success";
	private static final String FAIL = "fail";

	@Autowired
	private UserService userservice;

	
	@ApiOperation(value="특정 회원 정보를 반환한다. ", response=List.class)
	@PostMapping("/login")
	public ResponseEntity<UserDTO> login(@RequestBody UserDTO dto) {
		logger.debug("login - 호출");
		System.out.println(dto);
		UserDTO userinfo = userservice.selectOne(dto);
		System.out.println(userinfo!=null?"있는회원":"없는회원");
		System.out.println(userinfo);
//		if (helper.isMatch(userinfo.getUserpw(), dto.getUserpw())) {
//			
//		}
		if (userinfo != null) return new ResponseEntity<UserDTO>(userinfo,HttpStatus.OK);
		else return new ResponseEntity<UserDTO>(userinfo, HttpStatus.OK);
	}
	
	@ApiOperation(value="회원no 데이터로 특정 회원 정보를 반환한다. ", response=List.class)
	@GetMapping("/{no}")
	public ResponseEntity<UserDTO> selectOneByNo(@PathVariable int no) {
		logger.debug("login - 호출");
		UserDTO userinfo = userservice.selectOneByNo(no);
		System.out.println(userinfo!=null?"있는회원":"없는회원");
		if (userinfo != null) return new ResponseEntity<UserDTO>(userinfo,HttpStatus.OK);
		else return new ResponseEntity<UserDTO>(userinfo, HttpStatus.OK);
	}
	
	@ApiOperation(value="아이디 중복 체크 ", response=List.class)
	@PostMapping("/dupcheck")
	public ResponseEntity<String> checkIdDup(@RequestBody UserDTO dto) {
		logger.debug("checkIdDup - 호출");
		System.out.println(dto.getUserid());
		String uid = userservice.idDupCheck(dto.getUserid());
		System.out.println(uid!=null?"이미 존재하는 아이디":"없는 아이디");
		if (uid == null) return new ResponseEntity<String>("nexist",HttpStatus.OK);
		else return new ResponseEntity<String>("exist", HttpStatus.OK);
	}
	
	@ApiOperation(value="회원 가입시 작성한 id와 name으로 데이터로 pw 데이터를 반환한다. ", response=List.class)
	@PostMapping("/findpw")
	public ResponseEntity<String> findPw(@RequestBody UserDTO dto) {
		logger.debug("findPw - 호출");
		String pw = "";
		pw = userservice.findPw(dto.getUserid(), dto.getUsername());
		if (pw != null) return new ResponseEntity<String>(pw,HttpStatus.OK);
		else return new ResponseEntity<String>(pw, HttpStatus.OK);
	}
	
	@ApiOperation(value="새로운 회원 정보를 삽입한다.", response=List.class)
	@PostMapping
	public ResponseEntity<String> join(@RequestBody UserDTO userinfo) {
		logger.debug("join - 호출");
		System.out.println(userinfo.getUserid() + "의 회원가입 실행");
		int join = userservice.insert(userinfo);
		if (join == 1) return new ResponseEntity<String>(SUCCESS,HttpStatus.OK);
		else return new ResponseEntity<String>(FAIL, HttpStatus.OK);
	}
	
	@ApiOperation(value="회원 정보를 수정한다.", response=List.class)
	@PutMapping
	public ResponseEntity<String> update(UserDTO userinfo) {
		logger.debug("update - 호출");
		System.out.println(userinfo.getUserid() + "의 회원 정보 수정");
		int update = userservice.update(userinfo);
		if (update == 1) return new ResponseEntity<String>(SUCCESS,HttpStatus.OK);
		else return new ResponseEntity<String>(FAIL, HttpStatus.OK);
	}
	
}
