package com.ssafy.happyhouse.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.happyhouse.dto.DealDTO;
import com.ssafy.happyhouse.service.DealService;

import io.swagger.annotations.ApiOperation;

//http://localhost:9999/ssafyfinal/swagger-ui.html
@CrossOrigin(origins = { "*" }, maxAge = 6000)
@RestController
@RequestMapping("/api/deal")
public class DealController {
	private static final Logger logger = LoggerFactory.getLogger(DealController.class);
	private static final String SUCCESS = "success";
	private static final String FAIL = "fail";

	@Autowired
	private DealService dealService;

	@ApiOperation(value = "모든 부동산 거래 목록 정보를 반환한다.", response = List.class)
	@GetMapping
	public ResponseEntity<List<DealDTO>> retrieveDeal() throws Exception {
		logger.debug("retrieveDeal 호출");
		List<DealDTO> list = dealService.selectDealList();
		System.out.println(list.size());
		return new ResponseEntity<List<DealDTO>>(dealService.selectDealList(), HttpStatus.OK);
	}

	@ApiOperation(value = "특정 부동산 거래 목록 정보를 반환한다.", response = List.class)
	@GetMapping("/{no}")
	public ResponseEntity<DealDTO> selectOne(@PathVariable int no) throws Exception {
		logger.debug("selectOne 호출");
		DealDTO dto = dealService.selectOne(no);
		System.out.println(dto!=null?"있는매물목록":"없는매물목록");
		if (dto != null) return new ResponseEntity<DealDTO>(dto, HttpStatus.OK);
		else return new ResponseEntity<DealDTO>(dto, HttpStatus.OK);
	}

}
