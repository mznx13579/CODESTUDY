package com.ssafy.happyhouse.dto;

public class DailyDialectDTO {
	private int no;
	private String type;
	private String name;
	private String sitename;
	private String content;
	private String original;
	private String solution;
	private String soundurl;
	private String image1url;
	
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSitename() {
		return sitename;
	}
	public void setSitename(String sitename) {
		this.sitename = sitename;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getOriginal() {
		return original;
	}
	public void setOriginal(String original) {
		this.original = original;
	}
	public String getSolution() {
		return solution;
	}
	public void setSolution(String solution) {
		this.solution = solution;
	}
	public String getSoundurl() {
		return soundurl;
	}
	public void setSoundurl(String soundurl) {
		this.soundurl = soundurl;
	}
	public String getImage1url() {
		return image1url;
	}
	public void setImage1url(String image1url) {
		this.image1url = image1url;
	}
	@Override
	public String toString() {
		return "DailyDialectDTO [type=" + type + ", name=" + name + ", sitename=" + sitename + ", content=" + content
				+ ", original=" + original + ", solution=" + solution + ", soundurl=" + soundurl + ", image1url="
				+ image1url + "]";
	}
	
}

