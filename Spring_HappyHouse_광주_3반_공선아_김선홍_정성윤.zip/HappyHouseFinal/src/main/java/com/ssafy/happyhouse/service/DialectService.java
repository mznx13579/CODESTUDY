package com.ssafy.happyhouse.service;

import java.util.List;

import com.ssafy.happyhouse.dto.DailyDialectDTO;
import com.ssafy.happyhouse.dto.DialectDictionaryDTO;

public interface DialectService {
	public List<DailyDialectDTO> getDailyDialect();
	public List<DialectDictionaryDTO> getDialectDictionaryList();
	public DialectDictionaryDTO getDialectDictionaryOne(int no);	
}
