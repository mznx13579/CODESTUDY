package com.ssafy.happyhouse.repo;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.ssafy.happyhouse.dto.RealtorDTO;

@Mapper
public interface RealtorRepo {
	public List<RealtorDTO> selectRealtorList();
	public RealtorDTO selectRealtorOne(int no);
}
