package com.ssafy.happyhouse.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.happyhouse.dto.DealDTO;
import com.ssafy.happyhouse.repo.DealRepo;

@Service
public class DealServiceImpl implements DealService{
	@Autowired
	private DealRepo repo;

	@Override
	public List<DealDTO> selectDealList() {
		// TODO Auto-generated method stub
		return repo.selectDealList();
	}

	@Override
	public DealDTO selectOne(int no) {
		// TODO Auto-generated method stub
		return repo.selectOne(no);
	}

}
