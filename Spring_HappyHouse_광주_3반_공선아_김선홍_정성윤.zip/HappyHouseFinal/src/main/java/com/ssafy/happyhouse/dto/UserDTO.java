package com.ssafy.happyhouse.dto;

public class UserDTO {
	private int no;
	private String userid;
	private String userpw;
	private String username;
	
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getUserpw() {
		return userpw;
	}
	public void setUserpw(String userpw) {
		this.userpw = userpw;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	@Override
	public String toString() {
		return "UserDTO [no=" + no + ", userid=" + userid + ", userpw=" + userpw + ", username=" + username + "]";
	}
	
}
