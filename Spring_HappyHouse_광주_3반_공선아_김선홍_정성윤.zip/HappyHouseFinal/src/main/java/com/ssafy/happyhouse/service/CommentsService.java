package com.ssafy.happyhouse.service;

import java.util.List;

import com.ssafy.happyhouse.dto.CommentsDTO;

public interface CommentsService {
	public List<CommentsDTO> selectCommentsAllList();
	public List<CommentsDTO> selectCommentsList(int qno);
	public CommentsDTO selectCommentsOne(int qno, int no);
	public int insert(CommentsDTO dto);
	public int update(CommentsDTO dto);
	public int delete(int no);
}
