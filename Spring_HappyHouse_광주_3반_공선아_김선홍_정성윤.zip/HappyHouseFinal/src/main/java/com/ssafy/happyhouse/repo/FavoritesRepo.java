package com.ssafy.happyhouse.repo;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.ssafy.happyhouse.dto.DealDTO;
import com.ssafy.happyhouse.dto.FavoritesDTO;

@Mapper
public interface FavoritesRepo {
	public List<DealDTO> selectFavorites(int no);
	public List<DealDTO> selectFavDongDealList(int no);
	public FavoritesDTO check(int uno, int dno);
	public List<String> favDistinctDongist(int uno);
	public int insert(FavoritesDTO dto);
	public int delete(int no);
}
