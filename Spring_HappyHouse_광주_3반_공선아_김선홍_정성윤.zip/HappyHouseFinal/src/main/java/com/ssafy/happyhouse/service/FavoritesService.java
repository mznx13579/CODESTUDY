package com.ssafy.happyhouse.service;

import java.util.List;

import com.ssafy.happyhouse.dto.DealDTO;
import com.ssafy.happyhouse.dto.FavoritesDTO;

public interface FavoritesService {
	public List<DealDTO> selectFavorites(int no);
	public List<DealDTO> selectFavDongDealList(int no);
	public FavoritesDTO check(int uno, int dno);
	public List<String> favDistinctDongist(int uno);
	public int insert(FavoritesDTO dto);
	public int delete(int no);
}
