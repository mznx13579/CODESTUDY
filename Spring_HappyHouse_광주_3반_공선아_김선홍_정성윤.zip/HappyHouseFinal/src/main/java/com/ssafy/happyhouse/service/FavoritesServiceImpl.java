package com.ssafy.happyhouse.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.happyhouse.dto.DealDTO;
import com.ssafy.happyhouse.dto.FavoritesDTO;
import com.ssafy.happyhouse.repo.FavoritesRepo;

@Service
public class FavoritesServiceImpl implements FavoritesService{
	@Autowired
	FavoritesRepo repo;
	
	@Override
	public List<DealDTO> selectFavorites(int no) {
		// TODO Auto-generated method stub
		return repo.selectFavorites(no);
	}

	@Override
	public List<DealDTO> selectFavDongDealList(int no) {
		// TODO Auto-generated method stub
		return repo.selectFavDongDealList(no);
	}
	
	@Override
	public List<String> favDistinctDongist(int uno) {
		// TODO Auto-generated method stub
		return repo.favDistinctDongist(uno);
	}

	@Override
	public int insert(FavoritesDTO dto) {
		// TODO Auto-generated method stub
		return repo.insert(dto);
	}

	@Override
	public FavoritesDTO check(int uno, int dno) {
		// TODO Auto-generated method stub
		return repo.check(uno, dno);
	}

	@Override
	public int delete(int no) {
		// TODO Auto-generated method stub
		return repo.delete(no);
	}

}
