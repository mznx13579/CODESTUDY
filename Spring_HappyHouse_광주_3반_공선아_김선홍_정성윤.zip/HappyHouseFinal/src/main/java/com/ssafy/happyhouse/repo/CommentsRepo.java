package com.ssafy.happyhouse.repo;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.ssafy.happyhouse.dto.CommentsDTO;

@Mapper
public interface CommentsRepo {
	public List<CommentsDTO> selectCommentsAllList();
	public List<CommentsDTO> selectCommentsList(int qno);
	public CommentsDTO selectCommentsOne(int qno, int no);
	public int insert(CommentsDTO dto);
	public int update(CommentsDTO dto);
	public int delete(int no);
}
