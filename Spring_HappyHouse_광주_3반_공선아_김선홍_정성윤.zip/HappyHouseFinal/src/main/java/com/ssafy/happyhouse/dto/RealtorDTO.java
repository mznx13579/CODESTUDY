package com.ssafy.happyhouse.dto;

public class RealtorDTO {
	private int no;
	private String si;
	private String type;
	private String code;
	private String name;
	private String address;
	private String phone;
	private String regdate;
	
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public String getSi() {
		return si;
	}
	public void setSi(String si) {
		this.si = si;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getRegdate() {
		return regdate;
	}
	public void setRegdate(String regdate) {
		this.regdate = regdate;
	}
	@Override
	public String toString() {
		return "RealtorDTO [no=" + no + ", si=" + si + ", type=" + type + ", code=" + code + ", name=" + name
				+ ", address=" + address + ", phone=" + phone + ", regdate=" + regdate + "]";
	}
}
