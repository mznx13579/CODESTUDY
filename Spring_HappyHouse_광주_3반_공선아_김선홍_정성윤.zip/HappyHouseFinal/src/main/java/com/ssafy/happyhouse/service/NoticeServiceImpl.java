package com.ssafy.happyhouse.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.happyhouse.dto.NoticeDTO;
import com.ssafy.happyhouse.repo.NoticeRepo;

@Service
public class NoticeServiceImpl implements NoticeService{
	@Autowired
	NoticeRepo repo;
	
	@Override
	public List<NoticeDTO> selectList() {
		// TODO Auto-generated method stub
		return repo.selectList();
	}

	@Override
	public NoticeDTO selectOne(int no) {
		// TODO Auto-generated method stub
		return repo.selectOne(no);
	}

	@Override
	public int hit(int no) {
		// TODO Auto-generated method stub
		return repo.hit(no);
	}

	@Override
	public int insert(NoticeDTO dto) {
		// TODO Auto-generated method stub
		return repo.insert(dto);
	}

	@Override
	public int update(NoticeDTO dto) {
		// TODO Auto-generated method stub
		return repo.update(dto);
	}

	@Override
	public int delete(int no) {
		// TODO Auto-generated method stub
		return repo.delete(no);
	}

}
