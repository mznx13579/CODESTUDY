package com.ssafy.happyhouse.service;

import java.util.List;

import com.ssafy.happyhouse.dto.NoticeDTO;

public interface NoticeService {
	public List<NoticeDTO> selectList();
	public NoticeDTO selectOne(int no);
	public int hit(int no);
	public int insert(NoticeDTO dto);
	public int update(NoticeDTO dto);
	public int delete(int no);
}
