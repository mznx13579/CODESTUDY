package com.ssafy.happyhouse.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.happyhouse.dto.RealtorDTO;
import com.ssafy.happyhouse.repo.RealtorRepo;

@Service
public class RealtorServiceImpl implements RealtorService{
	@Autowired
	RealtorRepo repo;
	
	@Override
	public List<RealtorDTO> selectRealtorList() {
		// TODO Auto-generated method stub
		return repo.selectRealtorList();
	}

	@Override
	public RealtorDTO selectRealtorOne(int no) {
		// TODO Auto-generated method stub
		return repo.selectRealtorOne(no);
	}
	
}
