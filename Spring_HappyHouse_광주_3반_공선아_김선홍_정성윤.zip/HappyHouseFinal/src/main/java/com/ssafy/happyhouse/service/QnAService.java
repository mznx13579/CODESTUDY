package com.ssafy.happyhouse.service;

import java.util.List;

import com.ssafy.happyhouse.dto.QnADTO;

public interface QnAService {
	public List<QnADTO> selectQnAList();
	public QnADTO selectQnAOne(int no);
	public int insert(QnADTO dto);
	public int update(QnADTO dto);
	public int updateHit(int no);
	public int delete(int no);

}
