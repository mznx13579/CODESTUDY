package com.ssafy.happyhouse.dto;

public class CommentsDTO {
	private int no;
	private String userid;
	private String content;
	private String regtime;
	private int qno;
	
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getRegtime() {
		return regtime;
	}
	public void setRegtime(String regtime) {
		this.regtime = regtime;
	}
	public int getQno() {
		return qno;
	}
	public void setQno(int qno) {
		this.qno = qno;
	}
	@Override
	public String toString() {
		return "CommentsDTO [no=" + no + ", userid=" + userid + ", content=" + content + ", regtime=" + regtime
				+ ", qno=" + qno + "]";
	}
	
}
