package com.ssafy.happyhouse.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.happyhouse.dto.QnADTO;
import com.ssafy.happyhouse.repo.QnARepo;

@Service
public class QnAServiceImpl implements QnAService{
	
	@Autowired
	QnARepo repo;
	
	@Override
	public List<QnADTO> selectQnAList() {
		// TODO Auto-generated method stub
		return repo.selectQnAList();
	}

	@Override
	public QnADTO selectQnAOne(int no) {
		// TODO Auto-generated method stub
		return repo.selectQnAOne(no);
	}

	@Override
	public int insert(QnADTO dto) {
		// TODO Auto-generated method stub
		return repo.insert(dto);
	}

	@Override
	public int update(QnADTO dto) {
		// TODO Auto-generated method stub
		return repo.update(dto);
	}

	@Override
	public int updateHit(int no) {
		// TODO Auto-generated method stub
		return repo.updateHit(no);
	}

	@Override
	public int delete(int no) {
		// TODO Auto-generated method stub
		return repo.delete(no);
	}

}
