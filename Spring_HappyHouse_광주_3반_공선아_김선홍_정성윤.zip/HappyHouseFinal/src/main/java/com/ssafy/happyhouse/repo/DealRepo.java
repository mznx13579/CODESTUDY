package com.ssafy.happyhouse.repo;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.ssafy.happyhouse.dto.DealDTO;

@Mapper
public interface DealRepo {
	public List<DealDTO> selectDealList();
	public DealDTO selectOne(int no);
}
