package com.ssafy.happyhouse.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.happyhouse.dto.DailyDialectDTO;
import com.ssafy.happyhouse.dto.DialectDictionaryDTO;
import com.ssafy.happyhouse.repo.DialectRepo;

@Service
public class DialectServiceImpl implements DialectService{
	@Autowired
	DialectRepo repo;
	
	@Override
	public List<DailyDialectDTO> getDailyDialect() {
		// TODO Auto-generated method stub
		return repo.getDailyDialect();
	}

	@Override
	public List<DialectDictionaryDTO> getDialectDictionaryList() {
		// TODO Auto-generated method stub
		return repo.getDialectDictionaryList();
	}

	@Override
	public DialectDictionaryDTO getDialectDictionaryOne(int no) {
		// TODO Auto-generated method stub
		return repo.getDialectDictionaryOne(no);
	}

}
