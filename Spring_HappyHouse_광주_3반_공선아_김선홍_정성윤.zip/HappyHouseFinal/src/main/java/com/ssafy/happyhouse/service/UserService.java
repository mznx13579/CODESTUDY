package com.ssafy.happyhouse.service;

import com.ssafy.happyhouse.dto.UserDTO;

public interface UserService {
	public UserDTO selectOne(UserDTO userDTO);
	public UserDTO selectOneByNo(int no);
	public String findPw(String userid, String username);
	public int insert(UserDTO userDTO);
	public int update(UserDTO userDTO);
	public String idDupCheck(String userid);

}
