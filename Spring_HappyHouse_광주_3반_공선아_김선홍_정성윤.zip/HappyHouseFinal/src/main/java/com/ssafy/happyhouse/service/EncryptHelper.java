package com.ssafy.happyhouse.service;

public interface EncryptHelper {
	String encrypt(String pw);
	boolean isMatch(String pw, String hashed);
}
