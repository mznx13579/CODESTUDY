package com.ssafy.happyhouse.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.ssafy.happyhouse.service.BCryptImpl;
import com.ssafy.happyhouse.service.EncryptHelper;

@Configuration
public class WebConfig {
	@Bean
	public EncryptHelper encryptConfigure() {
		return new BCryptImpl();
	}
}
