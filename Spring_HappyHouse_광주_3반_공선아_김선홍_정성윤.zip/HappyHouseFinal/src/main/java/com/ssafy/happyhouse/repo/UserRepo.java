package com.ssafy.happyhouse.repo;

import org.apache.ibatis.annotations.Mapper;

import com.ssafy.happyhouse.dto.UserDTO;

@Mapper
public interface UserRepo {
	public UserDTO selectOne(UserDTO userDTO);
	public UserDTO selectOneByNo(int no);
	public String findPw(String userid, String username);
	public int insert(UserDTO userDTO);
	public int update(UserDTO userDTO);
	public String idDupCheck(String userid);
}
