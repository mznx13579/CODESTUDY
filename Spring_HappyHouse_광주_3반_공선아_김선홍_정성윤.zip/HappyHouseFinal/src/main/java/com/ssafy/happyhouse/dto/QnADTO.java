package com.ssafy.happyhouse.dto;

public class QnADTO {
	private int no;
	private String subject;
	private String content;
	private String regtime;
	private String userid;
	private int hit;
	
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getRegtime() {
		return regtime;
	}
	public void setRegtime(String regtime) {
		this.regtime = regtime;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public int getHit() {
		return hit;
	}
	public void setHit(int hit) {
		this.hit = hit;
	}
	@Override
	public String toString() {
		return "QnADTO [no=" + no + ", subject=" + subject + ", content=" + content + ", regtime=" + regtime
				+ ", userid=" + userid + ", hit=" + hit + "]";
	}
	
}
