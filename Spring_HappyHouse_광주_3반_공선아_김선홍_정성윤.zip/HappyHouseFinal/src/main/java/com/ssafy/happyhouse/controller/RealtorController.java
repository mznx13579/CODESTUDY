package com.ssafy.happyhouse.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.happyhouse.dto.RealtorDTO;
import com.ssafy.happyhouse.service.RealtorService;

import io.swagger.annotations.ApiOperation;

//http://localhost:9999/ssafyfinal/swagger-ui.html
@CrossOrigin(origins = { "*" }, maxAge = 6000)
@RestController
@RequestMapping("/api/realtor")
public class RealtorController {
	private static final Logger logger = LoggerFactory.getLogger(RealtorController.class);
	private static final String SUCCESS = "success";
	private static final String FAIL = "fail";
	
	@Autowired
	RealtorService realtorService;
	
	@ApiOperation(value="제주도 내의 모든 공인중개사 및 중개인 목록을 반환한다." , response = List.class)
	@GetMapping
	public ResponseEntity<List<RealtorDTO>> selectRealtorList(){
		logger.debug("selectRealtorList 호출");
		System.out.println("공인중개사 목록");
		return new ResponseEntity<List<RealtorDTO>>(realtorService.selectRealtorList(), HttpStatus.OK);
	}
	

	@ApiOperation(value="제주도 내의 특정 공인중개사 및 중개인 정보를 반환한다." , response = List.class)
	@GetMapping("/{no}")
	public ResponseEntity<RealtorDTO> selectRealtorOne(@PathVariable int no){
		logger.debug("selectRealtorOne 호출");
		System.out.println("공인중개사 목록");
		return new ResponseEntity<RealtorDTO>(realtorService.selectRealtorOne(no), HttpStatus.OK);
	}
	

}
