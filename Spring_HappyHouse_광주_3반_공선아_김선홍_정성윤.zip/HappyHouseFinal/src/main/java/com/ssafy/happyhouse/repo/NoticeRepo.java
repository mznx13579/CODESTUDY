package com.ssafy.happyhouse.repo;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.ssafy.happyhouse.dto.NoticeDTO;

@Mapper
public interface NoticeRepo {
	public List<NoticeDTO> selectList();
	public NoticeDTO selectOne(int no);
	public int hit(int no);
	public int insert(NoticeDTO dto);
	public int update(NoticeDTO dto);
	public int delete(int no);
}
