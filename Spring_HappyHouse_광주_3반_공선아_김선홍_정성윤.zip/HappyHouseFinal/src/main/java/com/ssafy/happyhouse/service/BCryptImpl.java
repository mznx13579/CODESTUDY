package com.ssafy.happyhouse.service;

import org.mindrot.jbcrypt.*;

public class BCryptImpl implements EncryptHelper{

	@Override
	public String encrypt(String pw) {
		// TODO Auto-generated method stub
		return BCrypt.hashpw(pw, BCrypt.gensalt());
	}

	@Override
	public boolean isMatch(String pw, String hashed) {
		// TODO Auto-generated method stub
		return BCrypt.checkpw(pw, hashed);
	}

}
