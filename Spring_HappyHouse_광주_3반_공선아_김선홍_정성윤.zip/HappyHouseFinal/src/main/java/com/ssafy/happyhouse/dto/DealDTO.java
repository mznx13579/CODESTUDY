package com.ssafy.happyhouse.dto;

public class DealDTO {
	private int no;
	private String address;
	private String dong;
	private String street;
	private String name;
	private double area;
	private String dealym;
	private String deald;
	private String price;
	private String deposit;
	private String monthly;
	private String floor;
	private String buildy;
	private String road;
	private String renttype;
	private int dealtype;
	
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getDong() {
		return dong;
	}
	public void setDong(String dong) {
		this.dong = dong;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getArea() {
		return area;
	}
	public void setArea(double area) {
		this.area = area;
	}
	public String getDealym() {
		return dealym;
	}
	public void setDealym(String dealym) {
		this.dealym = dealym;
	}
	public String getDeald() {
		return deald;
	}
	public void setDeald(String deald) {
		this.deald = deald;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getDeposit() {
		return deposit;
	}
	public void setDeposit(String deposit) {
		this.deposit = deposit;
	}
	public String getMonthly() {
		return monthly;
	}
	public void setMonthly(String monthly) {
		this.monthly = monthly;
	}
	public String getFloor() {
		return floor;
	}
	public void setFloor(String floor) {
		this.floor = floor;
	}
	public String getBuildy() {
		return buildy;
	}
	public void setBuildy(String buildy) {
		this.buildy = buildy;
	}
	public String getRoad() {
		return road;
	}
	public void setRoad(String road) {
		this.road = road;
	}
	public String getRenttype() {
		return renttype;
	}
	public void setRenttype(String renttype) {
		this.renttype = renttype;
	}
	public int getDealtype() {
		return dealtype;
	}
	public void setDealtype(int dealtype) {
		this.dealtype = dealtype;
	}
	
	@Override
	public String toString() {
		return "DealDTO [no=" + no + ", address=" + address + ", street=" + street + ", name=" + name + ", area=" + area
				+ ", dealym=" + dealym + ", deald=" + deald + ", price=" + price + ", deposit=" + deposit + ", monthly="
				+ monthly + ", floor=" + floor + ", buildy=" + buildy + ", road=" + road + ", renttype=" + renttype
				+ ", dealtype=" + dealtype + "]";
	}	
}
