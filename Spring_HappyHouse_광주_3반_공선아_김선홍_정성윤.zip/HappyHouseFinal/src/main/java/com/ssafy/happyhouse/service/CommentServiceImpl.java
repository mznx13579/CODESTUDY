package com.ssafy.happyhouse.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.happyhouse.dto.CommentsDTO;
import com.ssafy.happyhouse.repo.CommentsRepo;

@Service
public class CommentServiceImpl implements CommentsService{
	@Autowired
	CommentsRepo repo;
	
	@Override
	public List<CommentsDTO> selectCommentsAllList() {
		// TODO Auto-generated method stub
		return repo.selectCommentsAllList();
	}
	
	@Override
	public List<CommentsDTO> selectCommentsList(int qno) {
		// TODO Auto-generated method stub
		return repo.selectCommentsList(qno);
	}

	@Override
	public CommentsDTO selectCommentsOne(int qno, int no) {
		// TODO Auto-generated method stub
		return repo.selectCommentsOne(qno, no);
	}

	@Override
	public int insert(CommentsDTO dto) {
		// TODO Auto-generated method stub
		return repo.insert(dto);
	}

	@Override
	public int update(CommentsDTO dto) {
		// TODO Auto-generated method stub
		return repo.update(dto);
	}

	@Override
	public int delete(int no) {
		// TODO Auto-generated method stub
		return repo.delete(no);
	}

}
