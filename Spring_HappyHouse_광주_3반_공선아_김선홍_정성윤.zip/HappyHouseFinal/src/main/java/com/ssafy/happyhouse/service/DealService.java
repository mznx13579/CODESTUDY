package com.ssafy.happyhouse.service;

import java.util.List;

import com.ssafy.happyhouse.dto.DealDTO;

public interface DealService {
	public List<DealDTO> selectDealList();
	public DealDTO selectOne(int no);

}
