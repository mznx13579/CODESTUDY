package com.ssafy.happyhouse.dto;

public class FavoritesDTO {
	private int no;
	private String dong;
	private int uno;
	private int dno;
	
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public String getDong() {
		return dong;
	}
	public void setDong(String dong) {
		this.dong = dong;
	}
	public int getUno() {
		return uno;
	}
	public void setUno(int uno) {
		this.uno = uno;
	}
	public int getDno() {
		return dno;
	}
	public void setDno(int dno) {
		this.dno = dno;
	}
	@Override
	public String toString() {
		return "FavoritesDTO [no=" + no + ", dong=" + dong + ", uno=" + uno + ", dno=" + dno + "]";
	}
	
}
