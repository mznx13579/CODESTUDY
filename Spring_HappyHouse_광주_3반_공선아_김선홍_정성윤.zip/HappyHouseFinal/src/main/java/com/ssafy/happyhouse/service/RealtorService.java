package com.ssafy.happyhouse.service;

import java.util.List;

import com.ssafy.happyhouse.dto.RealtorDTO;

public interface RealtorService {
	public List<RealtorDTO> selectRealtorList();
	public RealtorDTO selectRealtorOne(int no);

}
