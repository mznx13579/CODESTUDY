package com.ssafy.happyhouse.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.happyhouse.dto.DailyDialectDTO;
import com.ssafy.happyhouse.dto.DialectDictionaryDTO;
import com.ssafy.happyhouse.service.DialectService;

import io.swagger.annotations.ApiOperation;

//http://localhost:9999/ssafyfinal/swagger-ui.html
@CrossOrigin(origins = { "*" }, maxAge = 6000)
@RestController
@RequestMapping("/api/dialect")
public class DialectController {

	private static final Logger logger = LoggerFactory.getLogger(DealController.class);
	private static final String SUCCESS = "success";
	private static final String FAIL = "fail";

	@Autowired
	private DialectService dialectService;
	
	@ApiOperation(value="생활방언 목록을 반환한다.", response = List.class)
	@GetMapping("/daily")
	public ResponseEntity<List<DailyDialectDTO>> getDailyDialect(){
		logger.debug("getDailyDialect 호출 ");
		List<DailyDialectDTO> list = dialectService.getDailyDialect();
		System.out.println(list.size());
		return new ResponseEntity<List<DailyDialectDTO>>(dialectService.getDailyDialect(),HttpStatus.OK);
	}

	@ApiOperation(value="방언 단어 목록을 반환한다.", response = List.class)
	@GetMapping("/dictionary")
	public ResponseEntity<List<DialectDictionaryDTO>> getDialectDictionaryList(){
		logger.debug("getDialectDictionaryList 호출 ");
		List<DialectDictionaryDTO> list = dialectService.getDialectDictionaryList();
		System.out.println(list.size());
		return new ResponseEntity<List<DialectDictionaryDTO>>(dialectService.getDialectDictionaryList(),HttpStatus.OK);
	}
}
