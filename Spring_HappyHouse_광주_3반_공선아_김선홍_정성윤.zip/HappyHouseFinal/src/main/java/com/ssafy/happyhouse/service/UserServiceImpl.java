package com.ssafy.happyhouse.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.happyhouse.dto.UserDTO;
import com.ssafy.happyhouse.repo.UserRepo;

@Service
public class UserServiceImpl implements UserService{
	@Autowired
	private UserRepo repo;
	@Autowired
	
	EncryptHelper helper;
	public UserServiceImpl(EncryptHelper helper) {
		this.helper = helper;
	}
	
	@Override
	public UserDTO selectOne(UserDTO userDTO) {
		// TODO Auto-generated method stub
		return repo.selectOne(userDTO);
	}

	@Override
	public UserDTO selectOneByNo(int no) {
		// TODO Auto-generated method stub
		return repo.selectOneByNo(no);
	}

	@Override
	public int insert(UserDTO userDTO) {
		// TODO Auto-generated method stub
//		String pp = helper.encrypt(userDTO.getUserpw());
//		System.out.println(pp);
//		userDTO.setUserpw(pp);
		return repo.insert(userDTO);
	}

	@Override
	public String findPw(String userid, String username) {
		// TODO Auto-generated method stub
		return repo.findPw(userid, username);
	}

	@Override
	public int update(UserDTO userDTO) {
		// TODO Auto-generated method stub
		return repo.update(userDTO);
	}

	@Override
	public String idDupCheck(String userid) {
		// TODO Auto-generated method stub
		return repo.idDupCheck(userid);
	}

}
