package com.ssafy.happyhouse.dto;

public class DialectDictionaryDTO {
	private int no;
	private String type;
	private String name;
	private String sitename;
	private String content;
	private String engcontent;
	private String jancontent;
	private String chicontent;
	private String sound;
	private String soundurl;
	
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSitename() {
		return sitename;
	}
	public void setSitename(String sitename) {
		this.sitename = sitename;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getEngcontent() {
		return engcontent;
	}
	public void setEngcontent(String engcontent) {
		this.engcontent = engcontent;
	}
	public String getJancontent() {
		return jancontent;
	}
	public void setJancontent(String jancontent) {
		this.jancontent = jancontent;
	}
	public String getChicontent() {
		return chicontent;
	}
	public void setChicontent(String chicontent) {
		this.chicontent = chicontent;
	}
	public String getSound() {
		return sound;
	}
	public void setSound(String sound) {
		this.sound = sound;
	}
	public String getSoundurl() {
		return soundurl;
	}
	public void setSoundurl(String soundurl) {
		this.soundurl = soundurl;
	}
	@Override
	public String toString() {
		return "DialectDictionaryDTO [no=" + no + ", type=" + type + ", name=" + name + ", sitename=" + sitename
				+ ", content=" + content + ", engcontent=" + engcontent + ", jancontent=" + jancontent + ", chicontent="
				+ chicontent + ", sound=" + sound + ", soundurl=" + soundurl + "]";
	}
}
