package com.ssafy.happyhouse.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.happyhouse.dto.DealDTO;
import com.ssafy.happyhouse.dto.FavoritesDTO;
import com.ssafy.happyhouse.service.FavoritesService;

import io.swagger.annotations.ApiOperation;

//http://localhost:9999/ssafyfinal/swagger-ui.html
@CrossOrigin(origins = { "*" }, maxAge = 6000)
@RestController
@RequestMapping("/api/favorites")
public class FavoritesController {
	private static final Logger logger = LoggerFactory.getLogger(FavoritesController.class);
	private static final String SUCCESS = "success";
	private static final String FAIL = "fail";
	
	@Autowired
	FavoritesService favoritesService;
	
	@ApiOperation(value="사용자no 데이터로 사용자가 즐겨찾기한 매물 목록을 반환한다. ")
	@GetMapping("/{no}")
	public ResponseEntity<List<DealDTO>> selectFavorites(@PathVariable int no){
		logger.debug("selectFavorites 호출");
		System.out.println(no + "번 회원의 목록 반환");
		return new ResponseEntity<List<DealDTO>>(favoritesService.selectFavorites(no), HttpStatus.OK);
	}
	
	@ApiOperation(value="사용자no 데이터로 사용자가 즐겨찾기한 동이름 목록을 중복제거하여 반환한다. ")
	@GetMapping("/fdong/{uno}")
	public ResponseEntity<List<String>> favDistinctDongist(@PathVariable int uno){
		logger.debug("favDistinctDongist 호출");
		System.out.println(uno + "번 회원의 즐겨찾기한 동이름 반환");
		return new ResponseEntity<List<String>>(favoritesService.favDistinctDongist(uno), HttpStatus.OK);
	}
	
	@ApiOperation(value="사용자no 데이터로 사용자가 즐겨찾기로 등록한 매물의 '동'에 대한 전체 매물 목록을 반환한다. ")
	@GetMapping("/fdlist/{no}")
	public ResponseEntity<List<DealDTO>> selectFavDongDealList(@PathVariable int no){
		logger.debug("selectFavDongDealList 호출");
		System.out.println(no + "번 회원의 즐겨찾기로 등록된 동에 대해 매물 목록 반환");
		return new ResponseEntity<List<DealDTO>>(favoritesService.selectFavDongDealList(no), HttpStatus.OK);
	}
	
	@ApiOperation(value="동이름, 사용자no, 매물 no 데이터로 즐겨찾기 찾기", response=List.class)
	@PostMapping
	public ResponseEntity<String> insert(@RequestBody FavoritesDTO dto){
		int update = favoritesService.insert(dto);
		System.out.println(dto.toString());
		if (update == 1) return new ResponseEntity<String>(SUCCESS ,HttpStatus.OK);
		else return new ResponseEntity<String>(FAIL, HttpStatus.OK);
	}
	
	@ApiOperation(value="사용자 uno와 매물정보 dno의 즐겨찾기 등록 여부 확인 ", response = List.class)
	@PostMapping("/fav")
	public ResponseEntity<String> check(@RequestBody FavoritesDTO dto){
		System.out.println("사용자 번호 : "+ dto.getUno() +", 매물 번호 : " + dto.getDno());
		FavoritesDTO ck = favoritesService.check(dto.getUno(), dto.getDno());
		if (ck != null) {
			System.out.println("즐겨찾기 등록되어있음 -> 등록 해제 - OFF ");
			int delete = favoritesService.delete(ck.getNo());
			System.out.println(delete == 1?"삭제 완료":"삭제 실패");
			return new ResponseEntity<String>("off",HttpStatus.OK);
		} else {
			System.out.println("즐겨찾기 등록 수행 - ON ");
			int insert = favoritesService.insert(dto);
			System.out.println(insert == 1?"추가완료":"추가실패");
			return new ResponseEntity<String>("on",HttpStatus.OK);
		}
	}
	
}
