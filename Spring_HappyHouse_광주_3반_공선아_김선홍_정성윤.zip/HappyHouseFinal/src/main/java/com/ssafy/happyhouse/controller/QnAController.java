package com.ssafy.happyhouse.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.happyhouse.dto.CommentsDTO;
import com.ssafy.happyhouse.dto.QnADTO;
import com.ssafy.happyhouse.service.CommentsService;
import com.ssafy.happyhouse.service.QnAService;

import io.swagger.annotations.ApiOperation;

//http://localhost:9999/ssafyfinal/swagger-ui.html
@CrossOrigin(origins = { "*" }, maxAge = 6000)
@RestController
@RequestMapping("/api/qna")
public class QnAController {
	private static final Logger logger = LoggerFactory.getLogger(QnAController.class);
	private static final String SUCCESS = "success";
	private static final String FAIL = "fail";
	
	@Autowired
	QnAService qnAService;
	@Autowired
	CommentsService commentsService;
	
	@ApiOperation(value="모든 QnA의 목록을 반환한다." , response=List.class)
	@GetMapping
	public ResponseEntity<List<QnADTO>> selectQnAList(){
		logger.debug("selectQnAList 호출");
		return new ResponseEntity<List<QnADTO>>(qnAService.selectQnAList(),HttpStatus.OK);
	}
	
	@ApiOperation(value="모든 댓글의 목록을 반환한다." , response=List.class)
	@GetMapping("/comments")
	public ResponseEntity<List<CommentsDTO>> selectCommentsAllList(){
		logger.debug("selectCommentsAllList 호출");
		return new ResponseEntity<List<CommentsDTO>>(commentsService.selectCommentsAllList(),HttpStatus.OK);
	}
	
	@ApiOperation(value="특정 QnA에 대한 상세정보를 반환한다." , response=List.class)
	@GetMapping("/{no}")
	public ResponseEntity<QnADTO> selectQnAOne(@PathVariable int no){
		logger.debug("selectQnAOne 호출");
		QnADTO dto = qnAService.selectQnAOne(no);
		if (dto != null) {
			qnAService.updateHit(no);
		}			
		return new ResponseEntity<QnADTO>(qnAService.selectQnAOne(no),HttpStatus.OK);
	}
	
	@ApiOperation(value="특정 QnA에 대한 댓글 목록을 반환한다." , response=List.class)
	@GetMapping("/{qno}/comments")
	public ResponseEntity<List<CommentsDTO>> selectCommentsList(@PathVariable int qno){
		logger.debug("selectCommentsList 호출");
		System.out.println(qno);
		return new ResponseEntity<List<CommentsDTO>>(commentsService.selectCommentsList(qno),HttpStatus.OK);
	}
	
	@ApiOperation(value="새로운 QnA를 추가한다." , response=List.class)
	@PostMapping
	public ResponseEntity<String> insertQnA(@RequestBody QnADTO dto){
		logger.debug("insertQnA 호출");
		int insert = qnAService.insert(dto);
		if (insert == 1) {
			return new ResponseEntity<String>(SUCCESS,HttpStatus.OK);			
		} else return new ResponseEntity<String>(FAIL,HttpStatus.OK);		
	}
	
	@ApiOperation(value="새로운 댓글을 추가한다." , response=List.class)
	@PostMapping("/comments")
	public ResponseEntity<String> insertComments(@RequestBody CommentsDTO dto){
		logger.debug("insertComments 호출");
		int insert = commentsService.insert(dto);
		System.out.println(dto.toString());
		if (insert == 1) {
			return new ResponseEntity<String>(SUCCESS,HttpStatus.OK);			
		} else return new ResponseEntity<String>(FAIL,HttpStatus.OK);		
	}
	
	@ApiOperation(value="특정 QnA를 수정한다." , response=List.class)
	@PutMapping
	public ResponseEntity<String> updateQnA(@RequestBody QnADTO dto){
		logger.debug("updateQnA 호출");
		int update = qnAService.update(dto);
		if (update == 1) {
			return new ResponseEntity<String>(SUCCESS,HttpStatus.OK);			
		} else return new ResponseEntity<String>(FAIL,HttpStatus.OK);		
	}
	
	@ApiOperation(value="특정 댓글을 수정한다." , response=List.class)
	@PutMapping("/comments")
	public ResponseEntity<String> updateComments(@RequestBody CommentsDTO dto){
		logger.debug("updateComments 호출");
		int update = commentsService.update(dto);
		if (update == 1) {
			return new ResponseEntity<String>(SUCCESS,HttpStatus.OK);			
		} else return new ResponseEntity<String>(FAIL,HttpStatus.OK);		
	}
	
	@ApiOperation(value="특정 QnA를 삭제한다." , response=List.class)
	@DeleteMapping("/{no}")
	public ResponseEntity<String> deleteQnA(@PathVariable int no){
		logger.debug("deleteQnA 호출");
		System.out.println(no+"삭제!@@@@@@@@@@@@");
		int delete = qnAService.delete(no);
		if (delete == 1) {
			return new ResponseEntity<String>(SUCCESS,HttpStatus.OK);			
		} else return new ResponseEntity<String>(FAIL,HttpStatus.OK);		
	}
	
	@ApiOperation(value="특정 댓글을 삭제한다." , response=List.class)
	@DeleteMapping("/comments/{no}")
	public ResponseEntity<String> deleteComments(@PathVariable int no){
		logger.debug("deleteComments 호출");
		System.out.println(no+"삭제!@@@@@@@@@@@@");
		int delete = commentsService.delete(no);
		if (delete == 1) {
			return new ResponseEntity<String>(SUCCESS,HttpStatus.OK);			
		} else return new ResponseEntity<String>(FAIL,HttpStatus.OK);		
	}
	

}
